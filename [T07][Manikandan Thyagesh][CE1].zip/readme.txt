TextBuddy Testing method

Execute the REGRESSIONTEST.bat file if you are using a windows machine

----Details------
In case you are using another machine, please note the following

For testinput.txt, the txt file to use is test.txt
For testinput2.txt, the txt file to use is test2.txt (do not alter the contents of this file!)

the expected output for each of them is expoutput.txt and expoutput2.txt resp.

xx End xx